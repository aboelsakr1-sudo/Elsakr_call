const express = require("express");
const http = require("http");
const { Server } = require("socket.io");

const app = express();

const server = http.createServer(app);

const io = new Server(server);

app.use(express.static("public"));

io.on("connection", (socket) => {

    console.log("User connected:", socket.id);

    // إرسال رسالة الدردشة
    socket.on("chat-message", (message) => {

        io.emit("chat-message", {
            id: socket.id,
            message: message
        });

    });

    // WebRTC signaling
    socket.on("offer", (offer) => {

        socket.broadcast.emit("offer", offer);

    });

    socket.on("answer", (answer) => {

        socket.broadcast.emit("answer", answer);

    });

    socket.on("ice-candidate", (candidate) => {

        socket.broadcast.emit("ice-candidate", candidate);

    });

    socket.on("disconnect", () => {

        console.log("User disconnected:", socket.id);

    });

});

server.listen(3000, () => {

    console.log("Server running:");
    console.log("http://localhost:3000");

});